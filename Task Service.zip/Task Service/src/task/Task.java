package task;
//KaLee Li
//CS320 Project One: Task
//April 6, 2023 
public class Task {
	private String taskId;
	private String taskName;
	private String taskDescr;
	
	public Task(String taskId, String taskName, String taskDescr) {
		if(taskId == null || taskId.length() > 10) {
			throw new IllegalArgumentException("Invalid Task ID");
		}
		if(taskName == null || taskName.length() > 10) {
			throw new IllegalArgumentException("Invalid task Name");}
		if(taskDescr == null || taskDescr.length() > 50) {
			throw new IllegalArgumentException("Invalid Task Description");}
		this.taskId = taskId;
		this.taskName = taskName;
		this.taskDescr = taskDescr;
	}
	// getters 
	public String getTaskId() {
		return taskId;
	}
	public String getTaskName() {
		return taskName;
	}
	public String getTaskDescr() {
		return taskDescr;
	}
	// set methods for update task purposes
	public void setTaskName(String addTaskName){
		if(taskName == null || taskName.length() > 20) {
			throw new IllegalArgumentException("Invalid Task Name");
		}
		this.taskName = addTaskName;
	}
	public void setTaskDescr(String addTaskDescr){
		if(taskDescr == null || taskDescr.length() > 50) {
			throw new IllegalArgumentException("Invalid Task Description");
		}
		this.taskDescr = addTaskDescr;
	}
}
