package task;
import java.util.ArrayList;

import task.Task;
//KaLee Li
//CS320 Project One: Task
//April 6, 2023 
public class TaskService {
	public String userTaskId;
	public String newTaskName;
	public String newTaskDescr;
	
	// creating a list to hold task
	public ArrayList <Task> taskList = new ArrayList <Task>(0);
	
	// add task 
	public void addTask(String userTaskId, String addTaskName, String addTaskDescr) {
		if(uniqueTaskId(userTaskId)== -1) {
			Task newTask = new Task(userTaskId, addTaskName, addTaskDescr);
			taskList.add(newTask);
		}

	}
	 // check uniqueTaskId
	public int uniqueTaskId(String userTaskId){
		// if uniqueId has match then throw Illegal Argument	
		for(int i = 0; i < taskList.size(); i++){
			if (userTaskId.equals(taskList.get(i).getTaskId())){
				throw new IllegalArgumentException("ID must be unique");
			}
		}
		return -1;
	}  
	// update Task Name
	public void updateTaskName(String userTaskId, String newTaskName){
		for(int i = 0; i < taskList.size(); i++){
			if (userTaskId.compareTo(taskList.get(i).getTaskId())== 0 ){
				taskList.get(i).setTaskName(newTaskName);
			}
			else {
				throw new IllegalArgumentException("Can't find matching ID");
			}

		}		
	}
	// update Task Description
	public void updateTaskDescr(String userTaskId, String newTaskDescr){
		for(int i = 0; i < taskList.size(); i++){
			if (userTaskId.compareTo(taskList.get(i).getTaskId())== 0 ){
				taskList.get(i).setTaskDescr(newTaskDescr);
			}
			else {
				throw new IllegalArgumentException("Can't find matching ID");
			}

		}		
	}
	// Delete Task
	public void deleteTask(String userTaskId){
		for(int i = 0; i < taskList.size(); i++){
			if (userTaskId.compareTo(taskList.get(i).getTaskId())== 0 ){
				int removeTask= i;
				taskList.remove(removeTask);
			}
			else {
				throw new IllegalArgumentException("Can't find matching ID");
			}
		}
	}	
	
	

}
