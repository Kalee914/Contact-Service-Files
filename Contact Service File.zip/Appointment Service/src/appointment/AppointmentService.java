package appointment;
import java.util.Date;
import java.util.ArrayList;
import appointment.Appointment;
//KaLee Li
//CS320 Project One: Appointment
//April 6, 2023
public class AppointmentService {
	public String userApptmentId;
	public Date newApptmentDate;
	public String newApptmentDescr; 
	
	// creating a list to hold appointment 
	public ArrayList <Appointment> apptmentList = new ArrayList <Appointment>(0);

	// add appointment
	public void addApptment(String userApptmentId, Date newApptmentDate, String newApptmentDescr) {
		if (uniqueApptmentId(userApptmentId)== -1) {
			Appointment newAppointment = new Appointment(userApptmentId, newApptmentDate, newApptmentDescr);
			apptmentList.add(newAppointment);
		}		
	}
	// check unique appointment ID 
	public int  uniqueApptmentId(String userApptmentId) {
		for(int i =0 ; i < apptmentList.size(); i++) {
			if (userApptmentId.equals(apptmentList.get(i).getApptmentId())) {
				throw new IllegalArgumentException("ID must be unique");
			}
		}
		return -1;
	}
	
	// Delete Appointment per appointment ID
	public void deleteApptment(String userApptmentId) {
		for(int i =0 ; i < apptmentList.size(); i++) {
			if (userApptmentId.compareTo(apptmentList.get(i).getApptmentId())== 0) {
				int removeApptment=i;
				apptmentList.remove(removeApptment);
			}
			else {
				throw new IllegalArgumentException("ID must be unique");
			}
		}
	}

}
