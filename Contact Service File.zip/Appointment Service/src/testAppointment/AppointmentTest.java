package testAppointment;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.Assert.assertTrue;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.Calendar;
import java.util.Date;
import appointment.Appointment;
//KaLee Li
//CS320 Project One: Appointment
//April 6, 2023
class AppointmentTest {

	@Test
	void testAppointmentClass() {
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 05);
		setTestDate.set(Calendar.DATE, 03);
		setTestDate.set(Calendar.YEAR, 2023);
		Date testDate = setTestDate.getTime();
		Appointment appointmentClass = new Appointment("12345",testDate ,"Appointment Description");
		assertTrue(appointmentClass.getApptmentId().equals("12345"));
		assertTrue(appointmentClass.getApptmentDate().equals(testDate));
		assertTrue(appointmentClass.getApptmentDescr().equals("Appointment Description"));
	}
	@Test
	void testApptmentIdTooLong() {
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 05);
		setTestDate.set(Calendar.DATE, 03);
		setTestDate.set(Calendar.YEAR, 2023);
		Date testDate = setTestDate.getTime();
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("12345678901",testDate ,"Appointment Description");});}
	@Test
	void testApptmentIdIsNull() {
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 05);
		setTestDate.set(Calendar.DATE, 03);
		setTestDate.set(Calendar.YEAR, 2023);
		Date testDate = setTestDate.getTime();
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment(null,testDate ,"Appointment Description");});}
	@Test
	void testApptmentDateIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("12345",null ,"Appointment Description");});}
	@Test
	void testApptmentDateIsBefore() {
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 03);
		setTestDate.set(Calendar.DATE, 01);
		setTestDate.set(Calendar.YEAR, 1996);
		Date testDate = setTestDate.getTime();
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("12345",testDate ,"Appointment Description");});}
	@Test
	void testApptmentDescrIsNull() {
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 05);
		setTestDate.set(Calendar.DATE, 30);
		setTestDate.set(Calendar.YEAR, 2023);
		Date testDate = setTestDate.getTime();
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("12345", testDate ,null);});}
	@Test
	void testApptmentDescrTooLong() {
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 05);
		setTestDate.set(Calendar.DATE, 01);
		setTestDate.set(Calendar.YEAR, 2023);
		Date testDate = setTestDate.getTime();
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Appointment("12345", testDate , "This string is to test appointment description is more than 50 characters.");});}
}
