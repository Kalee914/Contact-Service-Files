package testAppointment;
//KaLee Li
//CS320 Project One: Appointment
//April 6, 2023
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import appointment.AppointmentService;
import java.util.Calendar;
import java.util.Date;
class AppointmentServiceTest {

	@Test
	void testApptmentServiceClass() {
		AppointmentService as = new AppointmentService();
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 05);
		setTestDate.set(Calendar.DATE, 03);
		setTestDate.set(Calendar.YEAR, 2023);
		Date testDate = setTestDate.getTime();
		as.addApptment("12345", testDate, "Appointment Description");
		assertTrue(as.apptmentList.get(0).getApptmentId().equals("12345"));
		assertTrue(as.apptmentList.get(0).getApptmentDate().equals(testDate));
		assertTrue(as.apptmentList.get(0).getApptmentDescr().equals("Appointment Description"));
	}
	@Test
	void testAddApptmentWithMatchingId() {
		AppointmentService as = new AppointmentService();
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 05);
		setTestDate.set(Calendar.DATE, 03);
		setTestDate.set(Calendar.YEAR, 2023);
		Date testDate = setTestDate.getTime();
		as.addApptment("12345", testDate, "Appointment Description");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			as.addApptment("12345", testDate, "Appointment Description");});}
	@Test
	void testAddApptmentWithUniqueId() {
		AppointmentService as = new AppointmentService();
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 05);
		setTestDate.set(Calendar.DATE, 03);
		setTestDate.set(Calendar.YEAR, 2023);
		Date testDate = setTestDate.getTime();
		as.addApptment("12345", testDate, "Appointment Description");
		as.addApptment("1234567", testDate, "Appointment Description");
	}

	@Test
	void testDeleteApptment() {
		AppointmentService as = new AppointmentService();
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 05);
		setTestDate.set(Calendar.DATE, 03);
		setTestDate.set(Calendar.YEAR, 2023);
		Date testDate = setTestDate.getTime();
		as.addApptment("12345", testDate, "Appointment Description");
		as.deleteApptment("12345");		
	}
	@Test
	void testDeleteApptmentNoMatchId() {
		AppointmentService as = new AppointmentService();
		Calendar setTestDate = Calendar.getInstance();
		setTestDate.set(Calendar.MONTH, 05);
		setTestDate.set(Calendar.DATE, 03);
		setTestDate.set(Calendar.YEAR, 2023);
		Date testDate = setTestDate.getTime();
		as.addApptment("12345", testDate, "Appointment Description");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			as.deleteApptment("123456");});}

}
