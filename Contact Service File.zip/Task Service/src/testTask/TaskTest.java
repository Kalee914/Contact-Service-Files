package testTask;
import static org.junit.Assert.assertTrue;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import task.Task;
//KaLee Li
//CS320 Project One: Task
//April 6, 2023 
class TaskTest {

	@Test
	void testTaskClass() {
		Task taskClass = new Task("12345","TaskName","Test Description");
		assertTrue(taskClass.getTaskId().equals("12345"));
		assertTrue(taskClass.getTaskName().equals("TaskName"));
		assertTrue(taskClass.getTaskDescr().equals("Test Description"));
	}
	@Test
	void testTaskIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("12345456123","TaskName","Test Description");});}
	@Test
	void testTaskIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task(null,"TaskName","Test Description");});}
	@Test
	void testTaskNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("12345","TaskName is more than twenty characters","Test Description");});}
	@Test
	void testTaskNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("12345",null,"Test Description");});}
	@Test
	void testTaskDescrTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("12345","TaskName","Test Description now is more than 50 characters 23313212313131321313213113131");});}
	@Test
	void testTaskDescrisNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Task("12345","TaskName",null);});}
	@Test
	void testSetTaskName() {
		Task newTask = new Task("12345","TaskName","Test Description");
		newTask.setTaskName("newTaskName");
		assertTrue(newTask.getTaskName().equals("newTaskName"));}
	@Test
	void testSetTaskDescr() {
		Task newTask = new Task("12345","TaskName","Test Description");
		newTask.setTaskDescr("New Test Description");
		assertTrue(newTask.getTaskDescr().equals("New Test Description"));}
}
