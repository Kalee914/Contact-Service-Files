package testTask;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;


import task.TaskService;
//KaLee Li
//CS320 Project One: Task
//April 6, 2023 
class TaskServiceTest {

	@Test
	void testTaskServiceClass() {
		TaskService ts = new TaskService();
		ts.addTask("12345","TaskName","Test Description");
		assertTrue(ts.taskList.get(0).getTaskId().equals("12345"));
		assertTrue(ts.taskList.get(0).getTaskName().equals("TaskName"));
		assertTrue(ts.taskList.get(0).getTaskDescr().equals("Test Description"));
	}
	@Test
	void testAddtaskWithUniqueId() {
		TaskService ts = new TaskService();
		ts.addTask("12345","TaskName","Test Description");
		ts.addTask("12345678","TaskName","Test Description");
	}
	@Test
	void testAddtaskWithNotUniqueId() {
		TaskService ts = new TaskService();
		ts.addTask("12345","TaskName","Test Description");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			ts.addTask("12345","TaskName","Test Description");});
	}
	
	@Test
	void testUpdateTaskNamePerId() {
		TaskService ts = new TaskService();
		ts.addTask("12345","TaskName","Test Description");
		ts.updateTaskName("12345","new Task Name");
		assertTrue(ts.taskList.get(0).getTaskName().equals("new Task Name"));
	}
	@Test
	void testUpdateTaskNameNoMatchId() {
		TaskService ts = new TaskService();
		ts.addTask("12345","TaskName","Test Description");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			ts.updateTaskName("123456","new Task Name");});}
	
	@Test
	void testUpdateTaskDescrPerId() {
		TaskService ts = new TaskService();
		ts.addTask("12345","TaskName","Test Description");
		ts.updateTaskDescr("12345","New Test Description");
		assertTrue(ts.taskList.get(0).getTaskDescr().equals("New Test Description"));
	}
	
	@Test
	void testUpdateTaskNDescrNoMatchId() {
		TaskService ts = new TaskService();
		ts.addTask("12345","TaskName","Test Description");
		Assertions.assertThrows(IllegalArgumentException.class,()->{
			ts.updateTaskDescr("123456","Task Name");});}
	
	@Test
	void testDeleteTask() {
		TaskService ts = new TaskService();
		ts.addTask("12345","TaskName","Test Descriptions");
		ts.deleteTask("12345");
	}
	@Test
	void testDeleteTaskNoMatchId() {
		TaskService ts = new TaskService();
		ts.addTask("12345","TaskName","Test Descriptions");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			ts.deleteTask("1234567");});}
	
}
