package contact;
import java.util.ArrayList;
//KaLee Li
//CS320 Project One: Contact
//April 6, 2023

public class ContactService { 
	public String userId;
	public String newFirstName;
	public String newLastName;
	public String newPhoneNum;
	public String newAddress; 
	
	// creating a list to hold contact
	public ArrayList <Contact> contactList = new ArrayList <Contact>(0);
	

	// add contact method 
	public void addContact(String userId, String addFirstName, String addLastName, String addPhoneNum, String addAddress){
		if (uniqueId(userId)== -1) {
		Contact newContact = new Contact(userId, addFirstName, addLastName, addPhoneNum, addAddress);
		contactList.add(newContact);
		}
	}

	 // check uniqueId
	public int uniqueId(String userId){
		// if uniqueId has match then throw Illegal Argument	
		for(int i = 0; i < contactList.size(); i++){
			if (userId.equals(contactList.get(i).getContactId())){
				throw new IllegalArgumentException("ID must be unique");
			}
		}
		return -1;
	}  
	
	// update contact methods as per userId
	// if userId compare to contact list (index) and get id return to zero, 
	// that means it match then set the new info 
	public void updateFirstName(String userId, String newFirstName){
		for(int i = 0; i < contactList.size(); i++){
			if (userId.compareTo(contactList.get(i).getContactId())== 0 ){
				contactList.get(i).setFirstName(newFirstName);
			}
			else {
				throw new IllegalArgumentException("Can't find matching ID");
			}
		}
	}
	// update Last Name method
	public void updateLastName(String userId, String newLastName){
		for(int i = 0; i < contactList.size(); i++){
			if (userId.compareTo(contactList.get(i).getContactId())== 0 ){
				contactList.get(i).setLastName(newLastName);
			}
			else {
				throw new IllegalArgumentException("Can't find matching ID");
			}

		}		
	}
	// update Phone Number 
	public void updatePhoneNum (String userId, String newPhoneNum){
		for(int i = 0; i < contactList.size(); i++){
			if (userId.compareTo(contactList.get(i).getContactId())== 0 ){
				contactList.get(i).setPhoneNum(newPhoneNum);
			}
			else {
				throw new IllegalArgumentException("Can't find matching ID");
			}
		}		
	}
	
	// update Address
	public void updateAddress (String userId,String newAddress){
		for(int i = 0; i < contactList.size(); i++){
			if (userId.compareTo(contactList.get(i).getContactId())== 0 ){
				contactList.get(i).setAddress(newAddress);
			}
			else {
				throw new IllegalArgumentException("Can't find matching ID");
			}
		}		
	}
	
	// Delete Contact
	public void deleteContact(String userId){
		for(int i = 0; i < contactList.size(); i++){
			if (userId.compareTo(contactList.get(i).getContactId())== 0 ){
				int removeContact = i;
				contactList.remove(removeContact);
			}
			else {
				throw new IllegalArgumentException("Can't find matching ID");
			}
		}
	}	
}
