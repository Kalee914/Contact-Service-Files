package testContact;
import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import contact.Contact;
//KaLee Li
//CS320 Project One: Contact
//April 6, 2023

class ContactTest {

	@Test
	void testContactClas() {
		Contact contactClass = new Contact("12345" , "KaLee" , "Li" , "7189871234", "2 Hamilton Road, TN 37379" );
		assertTrue(contactClass.getContactId().equals("12345"));
		assertTrue(contactClass.getFirstName().equals("KaLee"));
		assertTrue(contactClass.getLastName().equals("Li"));
		assertTrue(contactClass.getPhoneNum().equals("7189871234"));
		assertTrue(contactClass.getAddress().equals("2 Hamilton Road, TN 37379"));
	}
	@Test
	void testContactIdTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("ContactIdTooLong" , "KaLee" , "Li" , "7189871234", 
					"2 Hamilton Road, TN 37379");});
	}
	@Test
	void testContactIdIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact(null , "KaLee" , "Li" , "7189871234", 
					"2 Hamilton Road, TN 37379");});
	}
	@Test
	void testFirstNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("12345" , "FirstNameTooLong" , "Li" , "7189871234", 
					"2 Hamilton Road, TN 37379");});
	}
	@Test
	void testFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("12345" , null , "Li" , "7189871234", 
					"2 Hamilton Road, TN 37379");});
	}
	@Test
	void testLastNameTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("12345" , "KaLee" , "LastNameTooLong" , "7189871234", 
					"2 Hamilton Road, TN 37379");});
	}
	@Test
	void testLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("12345" , "KaLee", null , "7189871234", 
					"2 Hamilton Road, TN 37379");});
	}
	@Test
	void testPhoneNumTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("12345" , "KaLee" , "Li" , "PhoneNumTooLong", 
					"2 Hamilton Road, TN 37379");});
	}
	@Test
	void testPhoneNumIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("12345" , "KaLee", "Li" , null, 
					"2 Hamilton Road, TN 37379");});
	}
	@Test
	void testAddressTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("12345" , "KaLee" , "Li" , "7189871234", 
					"2 Hamilton Road, East Brunswick, TN, 37379 AddressTOOLONG");});
	}
	@Test
	void testAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			new Contact("12345" , "KaLee", "Li" , "7189871234", 
					null);});
	}
	@Test
	void testSetFirstName() {
		Contact newContact = new Contact("12345", "Kalee", "lli", "1234567890", "address");
		newContact.setFirstName("newName");
		assertTrue(newContact.getFirstName().equals("newName"));
	}
	@Test
	void testSetLastName() {
		Contact newContact = new Contact("12345", "Kalee", "lli", "1234567890", "address");
		newContact.setLastName("newName");
		assertTrue(newContact.getLastName().equals("newName"));
	}
	
	@Test
	void testSetPhoneNum() {
		Contact newContact = new Contact("12345", "Kalee", "lli", "1234567890", "address");
		newContact.setPhoneNum("newName");
		assertTrue(newContact.getPhoneNum().equals("newName"));
	}
	@Test
	void testSetAddress() {
		Contact newContact = new Contact("12345", "Kalee", "lli", "1234567890", "address");
		newContact.setAddress("New Address");
		assertTrue(newContact.getAddress().equals("New Address"));
	}

}
