package contact;
//KaLee Li
//CS320 Project One: Contact
//April 6, 2023
public class Contact {
	private String contactId;
	private String firstName;
	private String lastName;
	private String phoneNum;
	private String address; 
	// The requirement for contactId CANNOT BE NULL, no longer than 10 characters, and not be update-able
	// firstName and lastName CANNOT BE NULL and no longer than 10 characters
	// phoneNum CANNOT BE NULL and must be exactly 10 digits
	// address CANNOT BE NULL and no longer than 30 characters
	public Contact(String contactId, String firstName, String lastName, String phoneNum, String address) {
		if(contactId == null || contactId.length() > 10) {
			throw new IllegalArgumentException("Invalid Contact ID");
		}
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");
		}
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		if(phoneNum == null || phoneNum.length() != 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		
		this.contactId = contactId;
		this.firstName = firstName;
		this.lastName =lastName;
		this.phoneNum = phoneNum;
		this.address = address;

	}
	
	// getters 
	public String getContactId() {
		return contactId;
	}
	public String getFirstName() {
		return firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public String getPhoneNum() {
		return phoneNum;
	}
	public String getAddress() {
		return address;
	}
// set methods for update contact purposes
	public void setFirstName(String addFirstName){
		if(firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Invalid First Name");}
		this.firstName = addFirstName;
	}
	public void setLastName(String addLastName){
		if(lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Invalid Last Name");
		}
		this.lastName = addLastName;
	}
	public void setPhoneNum(String addPhoneNum){
		if(phoneNum == null || phoneNum.length() > 10) {
			throw new IllegalArgumentException("Invalid Phone Number");
		}
		this.phoneNum = addPhoneNum;
	}
	public void setAddress (String addAddress){
		if(address == null || address.length() > 30) {
			throw new IllegalArgumentException("Invalid Address");
		}
		this.address = addAddress; 
	}	
}

