package testContact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.assertTrue;
import contact.ContactService;
//KaLee Li
//CS320 Project One: Contact
//April 6, 2023

class ContactServiceTest {

	@Test
	void testContactServiceClass() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		assertTrue(cs.contactList.get(0).getContactId().equals("12345"));
		assertTrue(cs.contactList.get(0).getFirstName().equals("KaLee"));
		assertTrue(cs.contactList.get(0).getLastName().equals("Li"));
		assertTrue(cs.contactList.get(0).getPhoneNum().equals("7189871234"));
		assertTrue(cs.contactList.get(0).getAddress().equals("2 Hamilton Road, TN 37379"));	
	}

	@Test 
	void testAddContactWithUniqueId(){
  		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		cs.addContact("1234578" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
  }
	@Test
	void testAddContactWithNotUniqueId() {
  		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			cs.addContact("12345" , "KaLee" , "Li" , 
					"7189871234", "2 Hamilton Road, TN 37379");});
	}

	@Test
	void testUpdateFirstNamePerId() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		cs.updateFirstName("12345" , "KaLe");
		assertTrue(cs.contactList.get(0).getFirstName().equals("KaLe"));
	}
	@Test
	void testUpdateFirstNameNoMatchId() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			cs.updateFirstName("123456" , "KaLe");});
	}
	@Test
	void testupdateLastNamePerId() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		cs.updateLastName("12345" , "newLastName");
		assertTrue(cs.contactList.get(0).getLastName().equals("newLastName"));
	}
	@Test
	void testupdateLastNameNoMatchId() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			cs.updateLastName("123456" , "NewLastName");});
		
	}
	@Test
	void testupdatePhoneNumPerId() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		cs.updatePhoneNum("12345" , "newPhoneNum");
		assertTrue(cs.contactList.get(0).getPhoneNum().equals("newPhoneNum"));
	}
	@Test
	void testupdatePhoneNumNoMatchId() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			cs.updatePhoneNum("123456" , "NewPhoneNum");});
		
	}
	@Test
	void testupdateAddressPerId() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		cs.updateAddress("12345" , "newAddress");
		assertTrue(cs.contactList.get(0).getAddress().equals("newAddress"));
	}
	@Test
	void testupdateAddressNoMatchId() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			cs.updateAddress("123456" , "NewAddress");});
		
	}
	@Test
	void testDeleteContact() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		cs.deleteContact("12345");
	}
	@Test
	void testDeleteContactNoMatchingId() {
		ContactService cs = new ContactService();
		cs.addContact("12345" , "KaLee" , "Li" , 
				"7189871234", "2 Hamilton Road, TN 37379");
		Assertions.assertThrows(IllegalArgumentException.class, ()-> {
			cs.deleteContact("123456");});
		
	}
	
}
