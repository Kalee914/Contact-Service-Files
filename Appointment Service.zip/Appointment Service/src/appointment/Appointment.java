package appointment;
import java.util.Date;
// KaLee Li
// CS320 Project One: Appointment
// April 6, 2023
public class Appointment {
	private String apptmentId;
	private Date apptmentDate;
	private String apptmentDescr; 
	
	public Appointment(String apptmentId, Date apptmentDate, String apptmentDescr) {
		if(apptmentId == null || apptmentId.length()>10) {
			throw new IllegalArgumentException("Invalid Appointment ID");	
		}
		if(apptmentDate == null || apptmentDate.before(new Date())) {			
			throw new IllegalArgumentException("Invalid Appointment Date");
		}
		if (apptmentDescr == null || apptmentDescr.length() > 50) {
			throw new IllegalArgumentException("Invalid Appointment Description");
		}
		this.apptmentId = apptmentId;
		this.apptmentDate = apptmentDate;
		this.apptmentDescr = apptmentDescr; 
	}
	// getters
	public String getApptmentId() {
		return apptmentId; 
	}
	public Date getApptmentDate() {
		return apptmentDate;
	}
	public String getApptmentDescr() {
		return apptmentDescr;
	}
	


}
